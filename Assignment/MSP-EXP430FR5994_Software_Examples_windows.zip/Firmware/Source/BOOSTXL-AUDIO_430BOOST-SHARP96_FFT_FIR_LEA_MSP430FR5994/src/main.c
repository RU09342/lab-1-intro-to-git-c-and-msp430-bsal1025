/* --COPYRIGHT--,BSD
 * Copyright (c) 2016, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * --/COPYRIGHT--*/
//******************************************************************************
//!  TI-Design Signal Processing with LEA on MSP430FR5994
//!
//!  Description: This TI-Design demonstrates the capabilities of Low Energy
//!               accelerator that performs a 256-point FFT or real-time 120-tap
//!               FIR filter. Use S1 to switch between 256-point FFT using LEA
//!               or 256-point FFT using CPU or FIR filtering.
//!               Once in FIR filtering mode, use S2 pushbutton to switch
//!               between different FIR filters from low-pass, high-pass, and
//!               band-stop filters.
//!
//!               NOTE: For FIR filtering mode, please use a headphone.
//!
//!                  MSP430FR5994               Sharp Boosterpack
//!               -----------------            |-----------------|
//!              |     P5.2/UCB1CLK|---------> |SPI_CLK  EXT_MODE|--GND
//!           /|\|                 |           |                 |
//!            | |    P5.0/UCB1SIMO|---------> |SPI_SI   EXTCOMIN|--GND
//!            --|RST              |           |                 |
//!              |             P1.3|---------> |SPI_CS           |
//!              |                 |           |                 |
//!              |             P6.2|---------> |DISP             |
//!              |                 |           |                 |
//!              |             P1.2|-----*---> |VDD              |
//!              |                 |      `--> |VDDA             |
//!              |                 |           |-----------------|
//!              |                 |            Audio Boosterpack
//!              |                 |           |-----------------|
//!              |                 |           |                 |
//!              |    P5.0/UCB1SIMO|---------> |SPI_SI           |
//!              |                 |           |                 |
//!              |     P5.2/UCB1CLK|---------> |SPI_CLK          |
//!              |                 |           |                 |
//!              |             P8.2|---------> |SYNC             |
//!              |                 |           |                 |
//!              |             P3.3|<--------- | MIC OUT         |
//!              |                 |           |                 |
//!              |             P4.1|---------> | MIC PWR         |
//!              |-----------------|           |-----------------|
//!
//******************************************************************************

#include <driverlib.h>
#include <stdio.h>
#include <stdlib.h>
#include "grlib.h"
#include "Sharp96x96.h"
#include "images.h"
#include "audio_collect.h"
#include "audio_playback.h"
#include "application.h"

void initClock(void);
void initGpio(void);

#if defined(__IAR_SYSTEMS_ICC__)
// Graphics binary image that gets loaded onto display
__persistent Graphics_Context g_sContext;
#elif defined(__TI_COMPILER_VERSION__)
// Graphics binary image that gets loaded onto display
#pragma PERSISTENT(g_sContext)
Graphics_Context g_sContext = {0};
#endif

// Global audio config parameter
Audio_configParams gAudioConfig;

// Global audio playback config parameter
Playback_configParams gPlaybackConfig;

int main(void)
{
    uint16_t gie;

    WDTCTL = WDTPW | WDTHOLD;       // Stop watchdog timer

    initClock();
    initGpio();

    PM5CTL0 &= ~LOCKLPM5;           // Clear lock bit

    // Enable Switch interrupt
    GPIO_clearInterrupt(PUSHBUTTON1_PORT, PUSHBUTTON1_PIN);
    GPIO_enableInterrupt(PUSHBUTTON1_PORT, PUSHBUTTON1_PIN);
    GPIO_clearInterrupt(PUSHBUTTON2_PORT, PUSHBUTTON2_PIN);
    GPIO_enableInterrupt(PUSHBUTTON2_PORT, PUSHBUTTON2_PIN);

    // Set up the LCD
    Sharp96x96_initDisplay();

    Graphics_initContext(&g_sContext, &g_sharp96x96LCD);
    Graphics_setForegroundColor(&g_sContext, ClrBlack);
    Graphics_setBackgroundColor(&g_sContext, ClrWhite);
    Graphics_setFont(&g_sContext, &g_sFontFixed6x8);
    Graphics_clearDisplay(&g_sContext);

    Graphics_flushBuffer(&g_sContext);
    // Store current GIE state
    gie = __get_SR_register() & GIE;
    __disable_interrupt();
    // Flush Buffer to LCD
    Graphics_flushBuffer(&g_sContext);
    // Restore original GIE state
    __bis_SR_register(gie);

    // Starts the application. It is a function that never returns.
    runApplication();

    return(1);
}

// Initializes the 32kHz crystal and MCLK to 8MHz
void initClock(void)
{
    PJSEL0 |= BIT4 | BIT5;                  // For XT1

    // XT1 Setup
    CSCTL0_H = CSKEY >> 8;                  // Unlock CS registers
    CSCTL1 = DCOFSEL_6;                     // Set DCO to 8MHz
    CSCTL2 = SELA__LFXTCLK | SELS__DCOCLK | SELM__DCOCLK;
    CSCTL3 = DIVA__1 | DIVS__1 | DIVM__1;   // set all dividers
    CSCTL4 &= ~LFXTOFF;

    do
    {
        CSCTL5 &= ~LFXTOFFG;                // Clear XT1 fault flag
        SFRIFG1 &= ~OFIFG;
    }
    while(SFRIFG1 & OFIFG);                 // Test oscillator fault flag
    CSCTL0_H = 0;                           // Lock CS registers
}

void initGpio(void)
{
    P1OUT = 0x00;
    P1DIR = 0xFF;

    P2OUT = 0x00;
    P2DIR = 0xFF;

    P3OUT = 0x00;
    P3DIR = 0xFF;

    P4OUT = 0x01;
    P4DIR = 0xFF;

    P5OUT = 0x00;
    P5DIR = 0xFF;

    P6OUT = 0x00;
    P6DIR = 0xFF;

    P7OUT = 0x00;
    P7DIR = 0xFF;

    P8OUT = 0x04;
    P8DIR = 0xFF;

    PJOUT = 0x00;
    PJDIR = 0xFF;

    // Configure Push button switch with high to low transition
    GPIO_setAsInputPinWithPullUpResistor(PUSHBUTTON1_PORT,
                                         PUSHBUTTON1_PIN);

    GPIO_selectInterruptEdge(PUSHBUTTON1_PORT,
                             PUSHBUTTON1_PIN,
                             GPIO_HIGH_TO_LOW_TRANSITION);

    GPIO_setAsInputPinWithPullUpResistor(PUSHBUTTON2_PORT,
                                         PUSHBUTTON2_PIN);

    GPIO_selectInterruptEdge(PUSHBUTTON2_PORT,
                             PUSHBUTTON2_PIN,
                             GPIO_HIGH_TO_LOW_TRANSITION);
}
